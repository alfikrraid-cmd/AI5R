from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200


def test_login():
    response = client.post("/login", json={"username": "demo", "password": "demo"})
    assert response.status_code == 200
    assert response.json()["access_token"] == "demo-token"
